"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.taskRouter = void 0;
var express_1 = require("express");
var constants_1 = require("../../../constants");
var http_status_codes_1 = __importDefault(require("http-status-codes"));
var ResponseFormat_1 = require("../../../core/ResponseFormat");
var di_container_1 = require("../../../di-container");
var boom_1 = __importDefault(require("boom"));
var router = (0, express_1.Router)();
exports.taskRouter = router;
var response = new ResponseFormat_1.ResponseFormat();
router.get('/all', function (req, res, next) {
    di_container_1.taskService.getAllTasks().then(function (tasks) {
        response.handleSuccess(res, {
            status: constants_1.messages.SUCCESS,
            statusCode: http_status_codes_1.default.OK,
            data: {
                tasks: tasks,
            }
        });
    }).catch(function (err) {
        console.error(err.message);
        var output = boom_1.default.badRequest(err.message).output;
        return response.handleError(res, output);
    });
});
router.get('/:id', function (req, res, next) {
    di_container_1.taskService.getTaskById(req.params.id).then(function (task) {
        response.handleSuccess(res, {
            status: constants_1.messages.SUCCESS,
            statusCode: http_status_codes_1.default.OK,
            data: {
                task: task,
            }
        });
    }).catch(function (err) {
        console.error(err.message);
        var output = boom_1.default.badRequest(err.message).output;
        return response.handleError(res, output);
    });
});
router.post('/create', function (req, res, next) {
    var doc = req.body;
    di_container_1.taskService.createTask(doc).then(function () {
        response.handleSuccess(res, {
            status: constants_1.messages.SUCCESS,
            statusCode: http_status_codes_1.default.OK,
            data: {
                message: "Task created successfully",
            }
        });
    }).catch(function (err) {
        console.log({ err: err });
        console.error(err.message);
        var output = boom_1.default.badRequest(err.message).output;
        return response.handleError(res, output);
    });
});
router.patch('/:id', function (req, res, next) {
    var doc = req.body;
    //TODO: add a validator schema
    di_container_1.taskService.updateTask(req.params.id, doc).then(function () {
        response.handleSuccess(res, {
            status: constants_1.messages.SUCCESS,
            statusCode: http_status_codes_1.default.OK,
            data: {
                message: "Task updated successfully",
            }
        });
    }).catch(function (err) {
        console.error(err.message);
        var output = boom_1.default.badRequest(err.message).output;
        return response.handleError(res, output);
    });
});
router.delete('/all', function (req, res, next) {
    di_container_1.taskService.deleteAllTasks().then(function () {
        response.handleSuccess(res, {
            status: constants_1.messages.SUCCESS,
            statusCode: http_status_codes_1.default.OK,
            data: {
                message: "Tasks deleted successfully",
            }
        });
    }).catch(function (err) {
        console.error(err.message);
        var output = boom_1.default.badRequest(err.message).output;
        return response.handleError(res, output);
    });
});
router.delete('/:id', function (req, res, next) {
    var doc = req.body;
    di_container_1.taskService.deleteTaskById(req.params.id).then(function () {
        response.handleSuccess(res, {
            status: constants_1.messages.SUCCESS,
            statusCode: http_status_codes_1.default.OK,
            data: {
                message: "Task deleted successfully",
            }
        });
    }).catch(function (err) {
        console.error(err.message);
        var output = boom_1.default.badRequest(err.message).output;
        return response.handleError(res, output);
    });
});
