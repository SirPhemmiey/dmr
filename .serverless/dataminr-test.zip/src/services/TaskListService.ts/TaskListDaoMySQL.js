"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TaskListDaoMySql = void 0;
var constants_1 = require("../../constants");
var TaskListDaoMySql = /** @class */ (function () {
    function TaskListDaoMySql(mysql) {
        this.pool = mysql;
    }
    TaskListDaoMySql.prototype.addTaskToList = function (task_id, tasklist_id) {
        return this.pool.execute("INSERT INTO ".concat(constants_1.Tables.TaskAssignment, "(task_id, tasklist_id)\n        VALUES (?, ?)"), [task_id, tasklist_id])
            .then(function () {
            return;
        });
    };
    TaskListDaoMySql.prototype.removeTaskFromList = function (task_id, tasklist_id) {
        return this.pool.execute("DELETE FROM ".concat(constants_1.Tables.TaskAssignment, " WHERE task_id = ? AND tasklist_id = ?"), [task_id, tasklist_id])
            .then(function () {
            return;
        });
    };
    TaskListDaoMySql.prototype.getTaskListsTasksById = function (tasklist_id) {
        // return this.pool.execute(`SELECT * FROM ${Tables.TaskAssignment} TAS,${Tables.TaskList} TL,${Tables.Task}TA 
        // JOIN TAS.task_id ON TA.id AND TAS.tasklist_id ON TL.id WHERE task_id = ?`, 
        // [task_id])
        // .then((result) => {
        //     return JSON.parse(JSON.stringify(result[0]))[0];
        // })
        return this.pool.execute("SELECT * FROM ".concat(constants_1.Tables.TaskAssignment, " AS TAS\n        JOIN ").concat(constants_1.Tables.Task, " AS TA ON TAS.task_id = TA.id WHERE tasklist_id = ?"), [tasklist_id])
            .then(function (result) {
            return JSON.parse(JSON.stringify(result[0]))[0];
        });
    };
    TaskListDaoMySql.prototype.deleteTaskListById = function (task_id) {
        return this.pool.execute("DELETE FROM ".concat(constants_1.Tables.TaskList, " WHERE id = ?"), [task_id])
            .then(function () {
            return;
        });
    };
    TaskListDaoMySql.prototype.deleteAllTaskLists = function () {
        return this.pool.execute("DELETE FROM ".concat(constants_1.Tables.TaskList))
            .then(function () {
            return;
        });
    };
    TaskListDaoMySql.prototype.createTaskList = function (doc) {
        return this.pool.execute("INSERT INTO ".concat(constants_1.Tables.TaskList, "(title, updated_at, created_at)\n        VALUES (?, ?, ?)"), [doc.title, doc.updated_at, doc.created_at])
            .then(function () {
            return;
        });
    };
    TaskListDaoMySql.prototype.updateTaskList = function (tasklist_id, doc) {
        return this.pool.execute("UPDATE ".concat(constants_1.Tables.TaskList, " SET title = ?, updated_at = ? WHERE id = ?"), [doc.title, doc.updated_at, tasklist_id])
            .then(function () {
            return;
        });
    };
    TaskListDaoMySql.prototype.getTaskListById = function (task_id) {
        return this.pool.execute("SELECT * FROM ".concat(constants_1.Tables.TaskList, " WHERE id = ?"), [task_id])
            .then(function (result) {
            return JSON.parse(JSON.stringify(result[0]))[0];
        });
    };
    TaskListDaoMySql.prototype.getAllTaskLists = function () {
        return this.pool.execute("SELECT * FROM ".concat(constants_1.Tables.TaskList))
            .then(function (result) {
            return JSON.parse(JSON.stringify(result[0]));
        });
    };
    return TaskListDaoMySql;
}());
exports.TaskListDaoMySql = TaskListDaoMySql;
