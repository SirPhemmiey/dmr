"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TaskDaoMySql = void 0;
var constants_1 = require("../../constants");
var TaskDaoMySql = /** @class */ (function () {
    function TaskDaoMySql(mysql) {
        this.pool = mysql;
    }
    TaskDaoMySql.prototype.deleteTaskById = function (task_id) {
        return this.pool.execute("DELETE FROM ".concat(constants_1.Tables.Task, " WHERE id = ?"), [task_id])
            .then(function () {
            return;
        });
    };
    TaskDaoMySql.prototype.deleteAllTasks = function () {
        return this.pool.execute("DELETE FROM ".concat(constants_1.Tables.Task))
            .then(function () {
            return;
        });
    };
    TaskDaoMySql.prototype.createTask = function (doc) {
        return this.pool.execute("INSERT INTO ".concat(constants_1.Tables.Task, "(title, description, status, updated_at, created_at)\n        VALUES (?, ?, ?, ?, ?)"), [doc.title, doc.description, doc.status, doc.updated_at, doc.created_at])
            .then(function () {
            return;
        });
    };
    TaskDaoMySql.prototype.updateTask = function (task_id, doc) {
        return this.pool.execute("UPDATE ".concat(constants_1.Tables.Task, " SET title = ?, description = ?, status = ?, updated_at = ? WHERE id = ?"), [doc.title, doc.description, doc.status, doc.updated_at, task_id])
            .then(function () {
            return;
        });
    };
    TaskDaoMySql.prototype.getTaskById = function (task_id) {
        return this.pool.execute("SELECT * FROM ".concat(constants_1.Tables.Task, " WHERE id = ?"), [task_id])
            .then(function (result) {
            return JSON.parse(JSON.stringify(result[0]))[0];
        });
    };
    TaskDaoMySql.prototype.getAllTasks = function () {
        return this.pool.execute("SELECT * FROM ".concat(constants_1.Tables.Task))
            .then(function (result) {
            return JSON.parse(JSON.stringify(result[0]));
        });
    };
    return TaskDaoMySql;
}());
exports.TaskDaoMySql = TaskDaoMySql;
