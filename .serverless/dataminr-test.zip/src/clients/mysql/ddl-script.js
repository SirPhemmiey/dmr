"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createTaskAssignmentTable = exports.createTaskListTable = exports.createTaskTable = void 0;
var constants_1 = require("../../constants");
var createTaskTable = function (conn) {
    return conn.execute("\n    CREATE TABLE IF NOT EXISTS ".concat(constants_1.Tables.Task, "\n    (\n    id INT PRIMARY KEY AUTO_INCREMENT,\n    title VARCHAR(100),\n    updated_at TIMESTAMP DEFAULT NULL,\n    created_at TIMESTAMP DEFAULT NULL,\n    description VARCHAR(100),\n    status VARCHAR(100)\n    );")).then(function () {
        //console.log('created task table');
    });
};
exports.createTaskTable = createTaskTable;
var createTaskListTable = function (conn) {
    return conn.execute("\n    CREATE TABLE IF NOT EXISTS ".concat(constants_1.Tables.TaskList, "\n    (\n    id INT PRIMARY KEY AUTO_INCREMENT,\n    title VARCHAR(100),\n    updated_at TIMESTAMP DEFAULT NULL,\n    created_at TIMESTAMP DEFAULT NULL\n    );")).then(function () {
        // console.log('created task list table');
    });
};
exports.createTaskListTable = createTaskListTable;
//apologies for this function name :)
var createTaskAssignmentTable = function (conn) {
    return conn.execute("\n    CREATE TABLE IF NOT EXISTS ".concat(constants_1.Tables.TaskAssignment, "\n    (\n    id INT PRIMARY KEY AUTO_INCREMENT,\n    task_id INT NOT NULL,\n    tasklist_id INT NOT NULL,\n    FOREIGN KEY (task_id) REFERENCES ").concat(constants_1.Tables.Task, "(id),\n    FOREIGN KEY (tasklist_id) REFERENCES ").concat(constants_1.Tables.TaskList, "(id)\n    );")).then(function () {
        // console.log('created task assignement table');
    });
};
exports.createTaskAssignmentTable = createTaskAssignmentTable;
