"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getMysqlPool = void 0;
var promise_1 = __importDefault(require("mysql2/promise"));
var env_1 = require("../../env");
var ddl_script_1 = require("./ddl-script");
var createConnection = function (options) {
    var conn = promise_1.default.createConnection({
        host: options.host,
        user: options.user,
        database: options.database,
        password: options.password
    });
    // conn.on('error', console.error.bind(console, 'mysql connection error:'));
    // conn.once('open', function callback() {
    //     return;
    // });
    return conn;
};
//connection pool improves latencies of queries
var createConnectionPool = function (options) {
    var conn = promise_1.default.createPool({
        host: options.host,
        user: options.user,
        database: options.database,
        password: options.password,
        waitForConnections: true,
        connectionLimit: 10,
        queueLimit: 0
    });
    return conn;
};
// export const getMysql = (): mysql.Connection => {
//     return createConnection({
//         host: getEnv().MYSQL_HOSTNAME,
//         user: getEnv().MYSQL_USER,
//         database: getEnv().MYSQL_DATABASE,
//         password: getEnv().MYSQL_PASSWORD
//     });
// }
var getMysqlPool = function () {
    return createConnectionPool({
        host: (0, env_1.getEnv)().MYSQL_HOSTNAME,
        user: (0, env_1.getEnv)().MYSQL_USER,
        database: (0, env_1.getEnv)().MYSQL_DATABASE,
        password: (0, env_1.getEnv)().MYSQL_PASSWORD
    });
};
exports.getMysqlPool = getMysqlPool;
//execute DDL script
Promise.all([
    (0, ddl_script_1.createTaskTable)((0, exports.getMysqlPool)()),
    (0, ddl_script_1.createTaskListTable)((0, exports.getMysqlPool)()),
    (0, ddl_script_1.createTaskAssignmentTable)((0, exports.getMysqlPool)())
]).then(function () {
    console.info('Successfully ran the DDL script');
}).catch(function (err) {
    //console.log({err});
    console.error('Error occured while running the DDL script', err.message);
});
