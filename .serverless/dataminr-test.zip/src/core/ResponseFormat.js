"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResponseFormat = void 0;
var express_1 = __importDefault(require("express"));
var ResponseFormat = /** @class */ (function () {
    function ResponseFormat() {
    }
    ResponseFormat.prototype.handleSuccess = function (res, obj) {
        var status = obj.status, statusCode = obj.statusCode, data = obj.data;
        return res.status(statusCode).json({
            statusCode: statusCode,
            status: status,
            data: data,
        });
    };
    ResponseFormat.prototype.handleError = function (res, obj) {
        res.status(obj.statusCode).json(obj);
    };
    ResponseFormat.prototype.handleErrorCustom = function (obj) {
        var res = express_1.default.response;
        res.status(obj.statusCode).json(obj);
    };
    return ResponseFormat;
}());
exports.ResponseFormat = ResponseFormat;
