"use strict";
/**
 *
 * Manual dependency injection was used here, but a dependency injection library like typedi could be used as normal practice
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.taskListService = exports.taskService = void 0;
var TaskDaoMySQL_1 = require("./services/TaskService/TaskDaoMySQL");
var TaskService_1 = require("./services/TaskService/TaskService");
var mysql_1 = require("./clients/mysql/mysql");
var TaskListService_1 = require("./services/TaskListService.ts/TaskListService");
var TaskListDaoMySQL_1 = require("./services/TaskListService.ts/TaskListDaoMySQL");
var taskDao = new TaskDaoMySQL_1.TaskDaoMySql((0, mysql_1.getMysqlPool)());
exports.taskService = new TaskService_1.TaskService(taskDao);
var taskListDao = new TaskListDaoMySQL_1.TaskListDaoMySql((0, mysql_1.getMysqlPool)());
exports.taskListService = new TaskListService_1.TaskListService(taskListDao);
