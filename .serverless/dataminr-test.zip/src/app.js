"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
var express_1 = __importDefault(require("express"));
// import {Logger} from './core/Logger';
var body_parser_1 = __importDefault(require("body-parser"));
var ApiError_1 = require("./core/ApiError");
var task_1 = require("./routes/v1/task");
var tasklist_1 = require("./routes/v1/tasklist");
var env_1 = require("./env");
var serverless_http_1 = __importDefault(require("serverless-http"));
process.on('uncaughtException', function (e) {
    console.error(e.message);
});
var app = (0, express_1.default)();
app.set("port", process.env.PORT || 3001);
app.get("/", function (req, res) {
    res.json({ status: "up" });
});
app.use(body_parser_1.default.json());
app.use(body_parser_1.default.urlencoded({ limit: '10mb', extended: true, parameterLimit: 50000 }));
// Routes
app.use('/v1/tasks', task_1.taskRouter);
app.use('/v1/tasklists', tasklist_1.tasklistRouter);
// catch 404 and forward to error handler
app.use(function (req, res, next) { return next(new ApiError_1.NotFoundError()); });
// Middleware Error Handler
// eslint-disable-next-line @typescript-eslint/no-unused-vars
app.use(function (err, req, res, next) {
    if (err instanceof ApiError_1.ApiError) {
        ApiError_1.ApiError.handle(err, res);
    }
    else {
        if ((0, env_1.getEnv)().NODE_ENV === 'development') {
            console.error(err.message);
            return res.status(500).send(err.message);
        }
        ApiError_1.ApiError.handle(new ApiError_1.InternalError(), res);
    }
});
exports.default = app;
exports.handler = (0, serverless_http_1.default)(app);
//module.exports.handler = serverless(app);
