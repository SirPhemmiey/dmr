"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Tables = exports.messages = void 0;
exports.messages = {
    SUCCESS: "success",
    FAILED: "failed",
};
var Tables;
(function (Tables) {
    Tables["Task"] = "task";
    Tables["TaskList"] = "tasklist";
    Tables["TaskAssignment"] = "taskassignment"; //to save references to tasks and task lists (re)assignments
})(Tables = exports.Tables || (exports.Tables = {}));
