"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getEnv = void 0;
var dotenv = __importStar(require("dotenv"));
dotenv.config();
var getEnv = function () {
    var _a, _b, _c, _d, _e;
    return {
        PORT: (_a = process.env.PORT) !== null && _a !== void 0 ? _a : '3001',
        NODE_ENV: process.env.NODE_ENV || '',
        MYSQL_DATABASE: (_b = process.env.MYSQL_DATABASE) !== null && _b !== void 0 ? _b : '',
        MYSQL_HOSTNAME: (_c = process.env.MYSQL_HOSTNAME) !== null && _c !== void 0 ? _c : '',
        MYSQL_USER: (_d = process.env.MYSQL_USER) !== null && _d !== void 0 ? _d : '',
        MYSQL_PASSWORD: (_e = process.env.MYSQL_PASSWORD) !== null && _e !== void 0 ? _e : ''
    };
};
exports.getEnv = getEnv;
