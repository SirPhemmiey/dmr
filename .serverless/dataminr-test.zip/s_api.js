
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'sirphemmiey',
  applicationName: 'dataminr-test',
  appUid: 'ZZfKgXXDmY5t92QMrb',
  orgUid: '017544e5-05f8-4f5f-9e90-c562da319d82',
  deploymentUid: 'c8e33708-0e80-4f07-9dc3-ed3d709f9444',
  serviceName: 'dataminr-test',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'dataminr-test-dev-api', timeout: 6 };

try {
  const userHandler = require('./src/app.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}